credentials = {
    "ssid": "{Galaxy F23 5G4200}",
    "password": "{charul04}",
    

    
}
VOSK_SERVER_URL = "http://192.168.219.54:5000/stt"
TRANSLATE_SPEAK_SERVER_URL = "http://192.168.219.54:5001/translate_speak"